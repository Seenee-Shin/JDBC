package edu.kh.jdbc.project.run;

import edu.kh.jdbc.project.view.MainView;

public class ProjectRun {
	public static void main(String[] args) {
		MainView main = new MainView();
		
		main.displayMenu();
	}

}
